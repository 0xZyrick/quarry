"use client";
import { AnimatePresence } from "framer-motion";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  EMPTY,
  Onboarding,
  canUseApp,
  isComplete,
  isSignedIn,
  onboardingAdapter,
} from "@/lib/onboarding";
import { useGuild } from "@/lib/store";
import OnboardingFlow from "./Onboarding";
import AuthModal from "./AuthModal";
import WelcomeStep from "./WelcomeStep";

type Api = {
  data: Onboarding;
  ready: boolean;
  complete: boolean;
  /** App chrome is usable (explored guest or signed in) */
  active: boolean;
  signedIn: boolean;
  update: (p: Partial<Onboarding>) => void;
  requireAuth: (reason: string) => void;
  clearAuth: () => void;
};

const Ctx = createContext<Api | null>(null);

export function useOnboarding() {
  const c = useContext(Ctx);
  if (!c) throw new Error("OnboardingProvider missing");
  return c;
}

/**
 * Welcome → look around (guest) or Explore (sign in).
 * requireAuth opens branded AuthModal (Drop in, Profile, etc.).
 */
export function OnboardingProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<Onboarding>(EMPTY);
  const [ready, setReady] = useState(false);
  const [bypass, setBypass] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authReason, setAuthReason] = useState("");

  useEffect(() => {
    const q = new URLSearchParams(location.search);
    if (q.get("onboarding") === "reset") {
      onboardingAdapter.clear();
      q.delete("onboarding");
      history.replaceState(
        null,
        "",
        location.pathname + (q.size ? `?${q}` : "") + location.hash
      );
    }
    setBypass(q.has("as") && process.env.NODE_ENV !== "production");
    setData(onboardingAdapter.read());
    setReady(true);
  }, []);

  const update = useCallback((p: Partial<Onboarding>) => {
    setData((d) => {
      const n = { ...d, ...p };
      onboardingAdapter.write(n);
      return n;
    });
  }, []);

  const clearAuth = useCallback(() => {
    onboardingAdapter.clear();
    setData({ ...EMPTY });
  }, []);

  const requireAuth = useCallback((reason: string) => {
    setAuthReason(reason || "continue");
    setAuthOpen(true);
  }, []);

  const signedIn = isSignedIn(data);
  const complete = isComplete(data);
  const active = ready && (bypass || canUseApp(data));
  const showWelcome = ready && !bypass && !canUseApp(data);

  // Push a minimal profile into guild store when signed in
  useEffect(() => {
    if (!ready) return;
    if (signedIn && data.uid && data.name) {
      useGuild.setState({
        profile: {
          id: data.uid,
          handle: data.name.replace(/^@/, "").toLowerCase(),
        } as any,
        profileReady: true,
      });
    } else {
      useGuild.setState({ profileReady: true });
    }
  }, [ready, signedIn, data.uid, data.name]);

  useEffect(() => {
    document.documentElement.toggleAttribute("data-onboarding", showWelcome);
  }, [showWelcome]);

  const api = useMemo<Api>(
    () => ({
      data,
      ready,
      complete,
      active,
      signedIn,
      update,
      requireAuth,
      clearAuth,
    }),
    [data, ready, complete, active, signedIn, update, requireAuth, clearAuth]
  );

  return (
    <Ctx.Provider value={api}>
      {children}

      {/* First visit — full-screen welcome */}
      <AnimatePresence>
        {showWelcome && (
          <div className="fixed inset-0 z-[60]">
            <WelcomeStep />
          </div>
        )}
      </AnimatePresence>

      {/* Optional deeper multi-step (only if you still mount Onboarding for signed users missing fields) */}
      <AnimatePresence>
        {ready && signedIn && !complete && !bypass && false && (
          <OnboardingFlow key="onboarding" />
        )}
      </AnimatePresence>

      {/* Drop in / Profile gate */}
      <AuthModal
        open={authOpen}
        reason={authReason}
        onClose={() => setAuthOpen(false)}
        onSuccess={() => setAuthOpen(false)}
      />
    </Ctx.Provider>
  );
}
